import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productos-list',
  templateUrl: './productos-list.component.html',
  styleUrls: ['./productos-list.component.css']
})
export class ProductosListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
