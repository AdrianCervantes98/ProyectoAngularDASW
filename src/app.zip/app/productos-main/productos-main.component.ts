import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productos-main',
  templateUrl: './productos-main.component.html',
  styleUrls: ['./productos-main.component.css']
})
export class ProductosMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
