import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-producto-detail',
  templateUrl: './producto-detail.component.html',
  styleUrls: ['./producto-detail.component.css']
})
export class ProductoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
