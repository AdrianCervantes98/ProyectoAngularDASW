import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productos-edit',
  templateUrl: './productos-edit.component.html',
  styleUrls: ['./productos-edit.component.css']
})
export class ProductosEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
