import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-main',
  templateUrl: './users-main.component.html',
  styleUrls: ['./users-main.component.css']
})
export class UsersMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
