import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Subscription } from 'rxjs';
import { UsersService } from '../users.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users: User[];

  subscript: Subscription;
  constructor(private userService: UsersService,
              private router: Router,
              private route: ActivatedRoute) { }

  ngOnInit() {
    this.users = this.userService.getUsers();
    this.subscript = this.userService.cambiaDato.subscribe(
      (arrayUsers: User[]) => {
        this.users = arrayUsers;
      }
    )
  }

  editar(user: User) {
    this.router.navigate(['/edit']);
    console.log(`El usuario a editar id: ${user.id} nombre: ${user.nombre}`);
  }

  crearUsuario() {
    this.router.navigate(['/register']);
  }

}
