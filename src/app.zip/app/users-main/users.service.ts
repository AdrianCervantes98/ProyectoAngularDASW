import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { User } from './user';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UsersService {

  cambiaDato = new Subject<User[]>();
  private lastid = 3;
  userLogged = false;
  loggedUser: User;
  admin: boolean;
  local = 'http://127.0.0.1:3003';

  public users: User[] = [];

  usersMails: string[] = [];

  admins: string[] = [];

  constructor(private http: HttpClient) { }

  getNextId(): number {
    return this.lastid;
  }

  containsMail(mail: string): boolean {
    return this.usersMails.includes(mail);
  }

  containsAdmin(mail: string): boolean {
    return this.admins.includes(mail);
  }

  addMail(mail: string) {
    this.usersMails.push(mail);
  }

  addUser(user: User) {
    let body = {
      id: this.lastid,
      nombre: user.nombre,
      domicilio: user.domicilio,
      fecha: user.fecha,
      cp: user.cp,
      mail: user.mail,
      password: user.password,
      rol: 'user',
      token: '123'
    };
    console.log(JSON.stringify(body));

    this.http.post(this.local + '/api/usuarios', body)
      .subscribe((data: User) => {
        console.log(data);
      }, (err) => {
        console.log(err);
      });
    this.lastid++;
    if (!this.containsMail(user.mail)) {
      this.addMail(user.mail);
      this.users.push(Object.assign({}, user));
      this.lastid++;
      this.notificarCambios();
    }
  }

  editUser(user: User) {
    const pos = this.users.findIndex(u => u.id === user.id);
    Object.assign(this.users[pos], user);
    this.notificarCambios();
  }

  getUsers() {
    this.http.get(this.local + '/api/usuarios')
      .subscribe((data: User[]) => {
        console.log(data);
        this.users = data;
        this.users.forEach(u => {
          this.addMail(u.mail);
          if (u.rol === 'admin') {
            this.admins.push(u.mail);
          }
        });
        console.log(this.users);
      }, (err) => {
        console.log(err);
      });
  }

  getUser(id: number): User {
    const pos = this.users.findIndex(u => u.id === id);
    return Object.assign({}, this.users[pos]);
  }

  private notificarCambios() {
    this.cambiaDato.next(this.users.slice());
  }

  passwordMatch(password: string, id: number): boolean {
    const user = this.getUser(id);
    return user.password === password;
  }

  getUserId(mail: string): number {
    if (this.containsMail(mail)) {
      let posMail = this.usersMails.indexOf(mail);
      posMail++;
      return posMail;
    }
  }


}
