import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  cambiaDato = new Subject<User[]>();
  private lastid = 1;

  users: User[] = [
    new User(this.lastid++, 'Pallandro', 'Avenida Primavera 123', new Date('05-03-1998'), 45050, 'pallandro@iteso.mx', 'pallandro'),
    new User(this.lastid++, 'Ian Gibson', 'Guadalupe 123', new Date('02-12-1998'), 46111, 'iangibson@iteso.mx', 'iangibson'),
    new User(this.lastid++, 'Harry Beltran', 'Cerro del cuatro 123', new Date('08-10-1996'), 45110, 'harry@iteso.mx', 'harrybeltran'),
  ];

  usersMails: string[] = [
    'pallandro@iteso.mx',
    'iangibson@iteso.mx',
    'harry@iteso.mx',
  ];

  constructor() { }

  getNextId(): number {
    return this.lastid;
  }

  containsMail(mail: string): boolean {
    return this.usersMails.includes(mail);
  }

  addMail(mail: string) {
    this.usersMails.push(mail);
  }

  addUser(user: User) {
    user.id = this.lastid;
    if (!this.containsMail(user.mail)) {
      this.addMail(user.mail);
      this.users.push(Object.assign({}, user));
      this.lastid++;
      this.notificarCambios();
    }
  }

  editUser(user: User) {
    const pos = this.users.findIndex(u => u.id === user.id);
    Object.assign(this.users[pos], user);
    this.notificarCambios();
  }

  getUsers(): User[] {
    return this.users.slice();
  }

  getUser(id: number): User {
    const pos = this.users.findIndex(u => u.id === id);
    return Object.assign({}, this.users[pos]);
  }

  private notificarCambios() {
    this.cambiaDato.next(this.users.slice());
  }

  passwordMatch(password: string, id: number): boolean {
    const user = this.getUser(id);
    return user.password === password;
  }

  getUserId(mail: string): number {
    if (this.containsMail(mail)) {
      let posMail = this.usersMails.indexOf(mail);
      posMail++;
      return posMail;
    }
  }


}
