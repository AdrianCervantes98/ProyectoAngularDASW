import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admins-main',
  templateUrl: './admins-main.component.html',
  styleUrls: ['./admins-main.component.css']
})
export class AdminsMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
