export class Venta {
    constructor(
        public nombre: string,
        public productos: string[],
        public cantidad: number[],
        public total: number,
    ) {}

}

